<div>
    <div style="clear:both;">
        <p style="margin-top:0pt; margin-bottom:0pt; text-align:right; line-height:108%; font-size:11pt;"><br></p>
    </div>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:12pt;"><strong><span style="font-family:'Times New Roman';">Features &ndash;&nbsp;</span></strong></p>
    <ul style="margin:0pt; padding-left:0pt;" type="disc">
        <li style="margin-left:102.25pt; line-height:108%; padding-left:5.75pt; font-family:serif; font-size:12pt;"><strong><span style="font-family:'Times New Roman';">One to One Chat.</span></strong></li>
        <li style="margin-left:102.25pt; line-height:108%; padding-left:5.75pt; font-family:serif; font-size:12pt;"><strong><span style="font-family:'Times New Roman';">Real **** chat.(without reloading page)</span></strong></li>
        <li style="margina-left:102.25pt; line-height:108%; padding-left:5.75pt; font-family:serif; font-size:12pt;"><strong><span style="font-family:'Times New Roman';">Read ticks.</span></strong></li>
        <li style="margin-left:102.25pt; line-height:108%; padding-left:5.75pt; font-family:serif; font-size:12pt;"><strong><span style="font-family:'Times New Roman';">Profile picture change.</span></strong></li>
        <li style="margin-left:102.25pt; line-height:108%; padding-left:5.75pt; font-family:serif; font-size:12pt;"><strong><span style="font-family:'Times New Roman';">Business Bots.</span></strong></li>
        <li style="margin-left:102.25pt; line-height:108%; padding-left:5.75pt; font-family:serif; font-size:12pt;"><strong><span style="font-family:'Times New Roman';">***** chat room.</span></strong></li>
        <li style="margin-left:102.25pt; line-height:108%; padding-left:5.75pt; font-family:serif; font-size:12pt;"><strong><span style="font-family:'Times New Roman';">Authentication.</span></strong></li>
        <li style="margin-left:102.25pt; line-height:108%; padding-left:5.75pt; font-family:serif; font-size:12pt;"><strong><span style="font-family:'Times New Roman';">Authorization.</span></strong></li>
    </ul>
    <p style="margin-top:0pt; margin-left:108pt; margin-bottom:0pt; line-height:108%; font-size:12pt;"><strong><span style="font-family:'Times New Roman';">&nbsp;</span></strong></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:11pt;"><span style="font-family:Calibri;">&nbsp;</span></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:12pt;"><br></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:16pt;"><span style="font-family:Calibri;">******* table Database:</span></p>
    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; line-height:108%; font-size:16pt;"><img src="https://myfiles.space/user_files/65454_9afc49ebb298f926/1616579348_1814026-32-report-wp-project/1616579348_1814026-32-report-wp-project.005.png" width="235" height="258" alt=""></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:16pt;"><span style="font-family:Calibri;">&nbsp;</span></p>
    <ul style="margin:0pt; padding-left:0pt;" type="disc">
        <li style="margin-left:32.66pt; line-height:108%; padding-left:3.34pt; font-family:serif; font-size:16pt;"><strong><span style="font-family:Calibri;">Profile Picture Change:&nbsp;</span></strong></li>
    </ul>
    <p style="margin-top:0pt; margin-left:36pt; margin-bottom:0pt; text-indent:36pt; line-height:108%; font-size:16pt;"><span style="font-family:Calibri;">** have **** ****** **** file upload *** the profile picture ****** and we save the address in mysql database and file in assets folder. We also delete the previous file ** profile picture is changed.</span></p>
    <p style="margin-top:0pt; margin-left:36pt; margin-bottom:0pt; text-indent:36pt; line-height:108%; font-size:16pt;"><img src="https://myfiles.space/user_files/65454_9afc49ebb298f926/1616579348_1814026-32-report-wp-project/1616579348_1814026-32-report-wp-project.006.png" width="536" height="101" alt=""></p>
    <p style="margin-top:0pt; margin-left:36pt; margin-bottom:0pt; text-indent:36pt; line-height:108%; font-size:16pt;"><span style="font-family:Calibri;">&nbsp;</span></p>
    <p style="margin-top:0pt; margin-left:36pt; margin-bottom:0pt; text-indent:36pt; line-height:108%; font-size:16pt;"><span style="font-family:Calibri;">Saved In assets folder.</span></p>
    <p style="margin-top:0pt; margin-left:36pt; margin-bottom:0pt; text-indent:36pt; line-height:108%; font-size:16pt;"><img src="https://myfiles.space/user_files/65454_9afc49ebb298f926/1616579348_1814026-32-report-wp-project/1616579348_1814026-32-report-wp-project.007.png" width="299" height="143" alt=""></p>
    <p style="margin-top:0pt; margin-left:36pt; margin-bottom:0pt; text-indent:36pt; line-height:108%; font-size:16pt;"><span style="font-family:Calibri;">&nbsp;</span></p>
    <p style="margin-top:0pt; margin-left:108pt; margin-bottom:0pt; line-height:108%; font-size:16pt;"><span style="font-family:Calibri;">Address of image in database:</span></p>
    <p style="margin-top:0pt; margin-left:36pt; margin-bottom:0pt; text-indent:36pt; line-height:108%; font-size:16pt;"><img src="https://myfiles.space/user_files/65454_9afc49ebb298f926/1616579348_1814026-32-report-wp-project/1616579348_1814026-32-report-wp-project.008.png" width="465" height="120" alt=""></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:14pt;"><span style="font-family:Calibri;">&nbsp;</span></p>
    <ul style="margin:0pt; padding-left:0pt;" type="disc">
        <li style="margin-left:32.66pt; line-height:108%; padding-left:3.34pt; font-family:serif; font-size:16pt;"><strong><span style="font-family:Calibri;">Business Bots:</span></strong></li>
    </ul>
    <p style="margin-top:0pt; margin-left:18pt; margin-bottom:0pt; line-height:108%; font-size:16pt;"><span style="font-family:Calibri;">We have used Mysql database , basic string search AI algorithm for appropriate reply of the bot. We have also used the timestamp in the replies.</span></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:16pt;"><img src="https://myfiles.space/user_files/65454_9afc49ebb298f926/1616579348_1814026-32-report-wp-project/1616579348_1814026-32-report-wp-project.009.png" width="614" height="351" alt=""></p>
    <p style="margin-top:0pt; margin-left:36pt; margin-bottom:0pt; text-indent:36pt; line-height:108%; font-size:16pt;"><span style="font-family:Calibri;">&nbsp;</span></p>
    <p style="margin-top:0pt; margin-left:36pt; margin-bottom:0pt; text-indent:36pt; line-height:108%; font-size:16pt;"><span style="font-family:Calibri;">Database of *** replies:</span></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:16pt;"><img src="https://myfiles.space/user_files/65454_9afc49ebb298f926/1616579348_1814026-32-report-wp-project/1616579348_1814026-32-report-wp-project.010.png" width="1037" height="55" alt=""></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:16pt;"><span style="font-family:Calibri;">&nbsp;</span></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:16pt;"><span style="font-family:Calibri;">&nbsp;</span></p>
    <ul style="margin:0pt; padding-left:0pt;" type="disc">
        <li style="margin-left:32.66pt; line-height:108%; padding-left:3.34pt; font-family:serif; font-size:16pt;"><strong><span style="font-family:Calibri;">Group chats:</span></strong></li>
    </ul>
    <p style="margin-top:0pt; margin-left:36pt; margin-bottom:0pt; line-height:108%; font-size:16pt;"><span style="font-family:Calibri;">We have used Mysql database , and the id,sender,body columns in database. And a complete dynamic get post request **** advanced javascript ** implement it.</span><span style="font-family:Calibri;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</span></p>
    <p style="margin-top:0pt; margin-left:36pt; margin-bottom:0pt; line-height:108%; font-size:16pt;"><span style="font-family:Calibri;">&nbsp;</span></p>
    <p style="margin-top:0pt; margin-left:36pt; margin-bottom:0pt; line-height:108%; font-size:16pt;"><span style="font-family:Calibri;">Screenshot ** this feature.</span></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:16pt;"><img src="https://myfiles.space/user_files/65454_9afc49ebb298f926/1616579348_1814026-32-report-wp-project/1616579348_1814026-32-report-wp-project.011.png" width="614" height="308" alt=""></p>
    <p style="margin-top:0pt; margin-left:108pt; margin-bottom:0pt; line-height:108%; font-size:14pt;"><span style="font-family:Calibri;">&nbsp;</span></p>
    <ul style="margin:0pt; padding-left:0pt;" type="disc">
        <li style="margin-left:31.46pt; line-height:108%; padding-left:4.54pt; font-family:serif; font-size:14pt;"><span style="font-family:Calibri;">1) Avoid Duplicacy of username:</span></li>
    </ul>
    <p style="margin-top:0pt; margin-left:36pt; margin-bottom:0pt; line-height:108%; font-size:14pt;"><img src="https://myfiles.space/user_files/65454_9afc49ebb298f926/1616579348_1814026-32-report-wp-project/1616579348_1814026-32-report-wp-project.012.png" width="266" height="239" alt=""><span style="font-family:Calibri;">&nbsp;</span></p>
    <p style="margin-top:0pt; margin-left:36pt; margin-bottom:0pt; line-height:108%; font-size:14pt;"><span style="font-family:Calibri;">&nbsp;</span></p>
    <ul style="margin:0pt; padding-left:0pt;" type="disc">
        <li style="margin-left:31.46pt; line-height:108%; padding-left:4.54pt; font-family:serif; font-size:14pt;"><span style="font-family:Calibri;">2) Avoid ********* of email.</span></li>
    </ul>
    <p style="margin-top:0pt; margin-left:36pt; margin-bottom:0pt; line-height:108%; font-size:14pt;"><img src="https://myfiles.space/user_files/65454_9afc49ebb298f926/1616579348_1814026-32-report-wp-project/1616579348_1814026-32-report-wp-project.013.png" width="516" height="77" alt=""></p>
    <ul style="margin:0pt; padding-left:0pt;" type="disc">
        <li style="margin-left:31.46pt; line-height:108%; padding-left:4.54pt; font-family:serif; font-size:14pt;"><span style="font-family:Calibri;">3)Authentication of email:</span><img src="https://myfiles.space/user_files/65454_9afc49ebb298f926/1616579348_1814026-32-report-wp-project/1616579348_1814026-32-report-wp-project.014.png" width="614" height="115" alt=""></li>
        <li style="margin-left:31.46pt; line-height:108%; padding-left:4.54pt; font-family:serif; font-size:14pt;"><span style="font-family:Calibri;">4)AJAX LIVE SEARCH :</span><img src="https://myfiles.space/user_files/65454_9afc49ebb298f926/1616579348_1814026-32-report-wp-project/1616579348_1814026-32-report-wp-project.015.png" width="247" height="275" alt=""></li>
        <li style="margin-left:31.46pt; line-height:108%; padding-left:4.54pt; font-family:serif; font-size:14pt;"><span style="font-family:Calibri;">5)Read ticks:</span><img src="https://myfiles.space/user_files/65454_9afc49ebb298f926/1616579348_1814026-32-report-wp-project/1616579348_1814026-32-report-wp-project.016.png" width="614" height="288" alt=""></li>
        <li style="margin-left:31.46pt; line-height:108%; padding-left:4.54pt; font-family:serif; font-size:14pt;"><span style="font-family:Calibri;">&nbsp;</span></li>
    </ul>
    <p style="margin-top:0pt; margin-left:36pt; margin-bottom:0pt; line-height:108%; font-size:14pt;"><span style="font-family:Calibri;">&nbsp;</span></p>
    <p style="margin-top:0pt; margin-left:36pt; margin-bottom:0pt; line-height:108%; font-size:11pt;"><span style="font-family:Calibri;">&nbsp;</span></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:11pt;"><br></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:12pt;"><span style="font-family:'Times New Roman';">&nbsp;</span></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:20pt;"><strong><span style="font-family:'Times New Roman';">&nbsp;</span></strong><strong><span style="font-family:'Times New Roman';">Conversation.php</span></strong><img src="https://myfiles.space/user_files/65454_9afc49ebb298f926/1616579348_1814026-32-report-wp-project/1616579348_1814026-32-report-wp-project.017.png" width="614" height="345" alt=""></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:20pt;"><strong><span style="font-family:'Times New Roman';">&nbsp;</span></strong></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:20pt;"><strong><span style="font-family:'Times New Roman';">Groups.php</span></strong></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:16pt;"><img src="https://myfiles.space/user_files/65454_9afc49ebb298f926/1616579348_1814026-32-report-wp-project/1616579348_1814026-32-report-wp-project.018.png" width="614" height="345" alt=""></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:16pt;"><strong><span style="font-family:Calibri;">SIGNUP.php</span></strong></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:11pt;"><img src="https://myfiles.space/user_files/65454_9afc49ebb298f926/1616579348_1814026-32-report-wp-project/1616579348_1814026-32-report-wp-project.019.png" width="614" height="345" alt=""></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:11pt;"><span style="font-family:Calibri;">&nbsp;</span></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:14pt;"><strong><span style="font-family:Calibri;">BOTS.PHP</span></strong></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:11pt;"><img src="https://myfiles.space/user_files/65454_9afc49ebb298f926/1616579348_1814026-32-report-wp-project/1616579348_1814026-32-report-wp-project.020.png" width="614" height="345" alt=""></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:11pt;"><br></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:14pt;"><strong><span style="font-family:Calibri;">SIGNIN:</span></strong></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:14pt;"><img src="https://myfiles.space/user_files/65454_9afc49ebb298f926/1616579348_1814026-32-report-wp-project/1616579348_1814026-32-report-wp-project.021.png" width="614" height="345" alt=""></p>
    <p style="margin-top:0pt; margin-bottom:0pt; font-size:14pt;"><span style="font-family:Calibri; background-color:#ffffff;">******** snapshot</span></p>
    <p style="margin-top:0pt; margin-bottom:0pt; font-size:14pt;"><span style="font-family:Calibri;">&nbsp;</span></p>
    <p style="margin-top:0pt; margin-bottom:0pt; font-size:14pt;"><img src="https://myfiles.space/user_files/65454_9afc49ebb298f926/1616579348_1814026-32-report-wp-project/1616579348_1814026-32-report-wp-project.022.png" width="341" height="240" alt=""></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:11pt;"><span style="font-family:Calibri;">&nbsp;</span></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:14pt;"><br></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:12pt;"><br></p>
    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; font-size:12pt;"><br></p>
    <div style="clear:both;"><br></div>
</div>
